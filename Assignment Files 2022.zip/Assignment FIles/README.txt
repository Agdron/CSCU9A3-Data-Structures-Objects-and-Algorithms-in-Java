Created by Duncan Mitchell

Steal this and you'll be forever cursed by the Computing Faculty at the University of Stirling and their obsession with Kittens

Project assignment contains various lumps of code based upon Object Oriented Programming, Algorithms such as Merge Sort and Data Structures